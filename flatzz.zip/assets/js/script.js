$(document).ready(function () {
  $(".hd_det").hide();
  $(".info_wrp").click(function () {
    $(this).find(".hd_det").toggle();
  });

  $(window).scroll(function () {
    if ($(window).scrollTop() >= 515) {
      $(".check_wrp").css("display", "block");
    } else {
      $(".check_wrp").css("display", "none");
    }
  });

  $(".slider_wrp").slick({
    dots: false,
    arrows: true,
    infinite: true,
    speed: 300,
    slidesToShow: 4,
    autoPlay: true,
    autoplaySpeed: 2000,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          infinite: true,
          dots: true,
        },
      },
      {
        breakpoint: 800,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
          dots: true,
          centerMode: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          centerMode: true,
        },
      },
      // {
      //   breakpoint: 480,
      //   settings: {
      //     slidesToShow: 1,
      //     slidesToScroll: 1,
      //   },
      // },
    ],
  });
  $(".pr_top").slick({
    dots: false,
    arrows: true,
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    autoPlay: true,
    autoplaySpeed: 2000,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          dots: true,
        },
      },
    ],
  });
  $(".propTabs").slick({
    dots: false,
    arrows: true,
    infinite: true,
    speed: 300,
    slidesToShow: 8,
    autoPlay: true,
    autoplaySpeed: 2000,
    autoPlay: true,
    slidesToScroll: 1,
    mobileFirst: true,
    responsive: [
      {
        breakpoint: 2000,
        settings: "unslick",
      },
      {
        breakpoint: 1600,
        settings: "unslick",
      },
      {
        breakpoint: 1024,
        settings: "unslick",
      },
      {
        breakpoint: 800,
        settings: {
          slidesToShow: 6,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
    ],
  });
});
